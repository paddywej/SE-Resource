#include <QApplication>
#include <QVBoxLayout>
#include <QPushButton>
#include "analogclock.h"
#include "ui_analogclock.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QPushButton>
#include <QMainWindow>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    AnalogClock analogClock;
    analogClock.setGeometry(210, 190, 300, 200);

    analogClock.show();
    analogClock.update();

    return a.exec();
}
