use assert_cmd::Command;

#[test]
fn circle() {
    let mut cmd = Command::cargo_bin("circle").unwrap(); 
    cmd.arg("0").assert().success().stdout("The area of a circle is 0\n"); 
}

#[test]
fn temf() {
    let mut cmd = Command::cargo_bin("temf").unwrap(); 
    cmd.arg("2").assert().success().stdout("Convert the temperature scale from °F to °C is -16.666668\n"); 
}

#[test]
fn temc() {
    let mut cmd = Command::cargo_bin("temc").unwrap(); 
    cmd.arg("2").assert().success().stdout("Convert the temperature scale from °C to °F is 35.6\n"); 
}
#[test]
fn no_arg() {
    let mut cmd = Command::cargo_bin("list_players").unwrap(); 
    cmd.assert().success().stdout("Player 1 : N/A\nPlayer 2 : N/A\n"); 
}

#[test]
fn one_args() {
    let mut cmd = Command::cargo_bin("list_players").unwrap(); 
    cmd.arg("Mike");
    cmd.assert().success().stdout("Player 1 : Mike\nPlayer 2 : N/A\n"); 
}

#[test]
fn two_args() {
    let mut cmd = Command::cargo_bin("list_players").unwrap(); 
    cmd.arg("Mike").arg("Leo");
    cmd.assert().success().stdout("Player 1 : Mike\nPlayer 2 : Leo\n"); 
}