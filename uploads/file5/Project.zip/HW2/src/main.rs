fn main() {
    let args: Vec<String> = std::env::args().collect();  
    let p1_arg = if args.len() <= 1 { "N/A" } else { &args[1] };
    let p2_arg = if args.len() <= 2 { "N/A" } else { &args[2] };
    println!("Player 1 : {}",p1_arg);
    println!("Player 2 : {}",p2_arg);
}